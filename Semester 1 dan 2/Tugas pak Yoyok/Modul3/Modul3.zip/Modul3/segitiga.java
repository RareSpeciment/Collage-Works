import java.util.Scanner;

public class segitiga {
        public static int triangle(int n) {
            int fact = 0;

            if (n < 0){
                fact = 0;
            }else{
                fact = triangle(n - 1) + n;

                for (int i = 0; i < n; i++){
                    System.out.print("[ "+ fact + " ]");
                }
                System.out.println();
            }
            return fact;
        }

        public static int getInput() {
            Scanner in = new Scanner(System.in);
            System.out.print("Masukkan angka : ");
            return in.nextInt();
        }

        public static void main(String[] args) {
            int pala = triangle(getInput());
        }
    }
